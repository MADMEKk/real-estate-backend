import React from 'react';
import { Dialog, DialogActions, DialogContent, DialogTitle, Button, IconButton } from '@mui/material';
import { Delete as DeleteIcon } from '@mui/icons-material';

const PhotoEditDialog = ({ open, onClose, photo, onDelete, onReplace }) => {
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            onReplace(photo.id, file);
        }
    };

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Edit Photo</DialogTitle>
            <DialogContent>
                <img src={photo.url} alt="Current" style={{ maxWidth: '100%' }} />
            </DialogContent>
            <DialogActions>
                <input
                    accept="image/*"
                    style={{ display: 'none' }}
                    id="replace-photo"
                    type="file"
                    onChange={handleFileChange}
                />
                <label htmlFor="replace-photo">
                    <Button color="primary" component="span">
                        Replace
                    </Button>
                </label>
                <IconButton color="secondary" onClick={() => onDelete(photo.id)}>
                    <DeleteIcon />
                </IconButton>
                <Button onClick={onClose} color="primary">
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default PhotoEditDialog;
