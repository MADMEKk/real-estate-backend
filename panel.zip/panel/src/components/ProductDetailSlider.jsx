import React from "react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

const ProductDetailSlider = ({ photos, onPhotoClick }) => {
    return (
        <div className="carousel-root">
            <div className="carousel-container">
                <div className="main-carousel">
                    <Carousel showArrows={true}>
                        {photos && photos.map((image, index) => (
                            <div key={index} className="slide" onClick={() => onPhotoClick(image)}>
                                <img
                                    style={{ borderRadius: "5px", width: "100%" }}
                                    src={`http://127.0.0.1:8000/mediafile/${image.image}`}
                                    alt={`Slide ${index}`}
                                />
                            </div>
                        ))}
                    </Carousel>
                </div>
            </div>
        </div>
    );
};

export default ProductDetailSlider;
