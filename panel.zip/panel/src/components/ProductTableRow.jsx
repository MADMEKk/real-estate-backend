import React from "react";
import { TableRow, TableCell, IconButton, Link } from "@mui/material";
import { Bathtub, LocalHotel, Expand, Publish, Block } from "@mui/icons-material";
import {useLocation, useNavigate} from "react-router-dom";

const ProductTableRow = ({ property, onPublish, onUnpublish }) => {
    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const trimmedPathname = pathname.replace("/Request for sale", "");

    const productDetailsLink = `${trimmedPathname}/product/${property.slug}`;
    const handlePublish = () => {
        onPublish(property.slug);
    };

    const handleUnpublish = () => {
        onUnpublish(property.slug);
    };

    return (
        <TableRow>
            <Link
                to={productDetailsLink}
                onClick={() => {
                    navigate(productDetailsLink); // Redirect to the product details page
                }}
            >
            <TableCell>{property.slug}</TableCell>
            <TableCell>{property.user}</TableCell>
            <TableCell>{property.createdAt}</TableCell>
            <TableCell>{numberWithCommas(property.price)} DZD</TableCell>
            <TableCell>{property.bedrooms}</TableCell>
            <TableCell>{property.bathrooms}</TableCell>
            <TableCell>{property.advert_type}</TableCell>
            <TableCell>{property.property_type}</TableCell>
            <TableCell>{property.published_status ? "Yes" : "No"}</TableCell>
            <TableCell>
                {property.published_status ? (
                    <IconButton aria-label="Unpublish" onClick={() => onUnpublish(property.slug)}>
                        <Block />
                    </IconButton>
                ) : (
                    <IconButton aria-label="Publish" onClick={() => onPublish(property.slug)}>
                        <Publish />
                    </IconButton>
                )}
            </TableCell>
            </Link>
        </TableRow>

    );
};

export default ProductTableRow;
