// ProductForm.js
import React from "react";
import {
    Button,
    Container,
    FormControl,
    Grid,
    TextField,
    Radio,
    RadioGroup,
    FormControlLabel,
    FormLabel,
} from "@mui/material";


const ProductForm = ({ editedProperty, handleInputChange, handleFileChange, handleRadioChange, handleUpdate }) => {
    return (
        <Container>
            <div className="product-details">
                <h2>Edit Product</h2>
                {editedProperty && (
                    <form onSubmit={handleUpdate} encType="multipart/form-data">
                        <FormControl fullWidth>
                            <TextField
                                label="Title"
                                name="title"
                                value={editedProperty.title || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Slug"
                                name="slug"
                                value={editedProperty.slug || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Reference Code"
                                name="ref_code"
                                value={editedProperty.ref_code || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Description"
                                name="description"
                                value={editedProperty.description || ''}
                                onChange={handleInputChange}
                                margin="normal"
                                multiline
                            />
                            <TextField
                                label="City"
                                name="city"
                                value={editedProperty.city || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Postal Code"
                                name="postal_code"
                                value={editedProperty.postal_code || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Street Address"
                                name="street_address"
                                value={editedProperty.street_address || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Property Number"
                                name="property_number"
                                value={editedProperty.property_number || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Price"
                                name="price"
                                value={editedProperty.price || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Tax"
                                name="tax"
                                value={editedProperty.tax || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Final Property Price"
                                name="final_property_price"
                                value={editedProperty.final_property_price || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Plot Area"
                                name="plot_area"
                                value={editedProperty.plot_area || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Total Floors"
                                name="total_floors"
                                value={editedProperty.total_floors || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Bedrooms"
                                name="bedrooms"
                                value={editedProperty.bedrooms || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Bathrooms"
                                name="bathrooms"
                                value={editedProperty.bathrooms || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Advertisement Type"
                                name="advert_type"
                                value={editedProperty.advert_type || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <TextField
                                label="Property Type"
                                name="property_type"
                                value={editedProperty.property_type || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />

                            <FormControl component="fieldset" fullWidth>
                                <FormLabel component="legend">Published Status</FormLabel>
                                <RadioGroup
                                    aria-label="published-status"
                                    name="published_status"
                                    value={editedProperty.published_status ? 'yes' : 'no'}
                                    onChange={handleRadioChange}
                                    row
                                >
                                    <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                                    <FormControlLabel value="no" control={<Radio />} label="No" />
                                </RadioGroup>
                            </FormControl>
                            <TextField
                                label="Views"
                                name="views"
                                value={editedProperty.views || ''}
                                onChange={handleInputChange}
                                margin="normal"
                            />
                            <Button type="submit" variant="contained" color="primary">
                                Update
                            </Button>
                        </FormControl>
                    </form>
                )}
            </div>
        </Container>
    );
};

export default ProductForm;
