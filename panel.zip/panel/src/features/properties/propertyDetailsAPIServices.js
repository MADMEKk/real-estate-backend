import axios from "axios";
import {useEffect, useState} from "react";
import {createAsyncThunk} from "@reduxjs/toolkit";
export const getPropertyPhotos = async (slug) => {
  try {
    const response = await axios.get(`http://127.0.0.1:8000/api/v1/properties/photos/${slug}/`);
    return response.data;
  } catch (error) {
    console.error("Error fetching property photos:", error);
    throw error;
  }
};

export const getPropertyDetails = async (slug) => {
  try {
    const response = await axios.get(`http://127.0.0.1:8000/api/v1/properties/details/${slug}/`);
    return response.data;
  } catch (error) {
    // Handle error
    console.error("Error fetching property details:", error);
    throw error;
  }
};
// api.js


const getToken = () => {
  // Implement your logic to retrieve the JWT token from local storage or any other source
  return  JSON.parse(localStorage.getItem("user")).access; // Get the JWT access token from local storage

};

const api = axios.create({
  baseURL: "http://127.0.0.1:8000/api/v1/properties/update/",
  headers: {
    "Content-Type": "application/json",
  },
});


export const updatePropertyapi = async (updatedProperty) => {
  try {
    const token = getToken();
    const response = await api.put(`${updatedProperty.slug}/`, updatedProperty, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const replacePropertyPhotoApi = async (propertyId, photoId, formData) => {
  const token = getToken();
  const response = await axios.put(`http://127.0.0.1:8000/api/v1/properties/update/${propertyId}/photo/${photoId}/`, formData, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'multipart/form-data'
    }
  });
  return response;
};


export default getPropertyDetails;
