import React from "react";
import { Route, Navigate } from "react-router-dom";

const PrivateRoute = ({ children, isAuthenticated, ...rest }) => {
    return isAuthenticated ? (
        <Route {...rest} element={children} />
    ) : (
        <Navigate to="/login" replace />
    );
};

export default PrivateRoute;
