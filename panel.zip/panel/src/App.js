import React, {useEffect, useMemo} from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { createTheme } from "@mui/material/styles";
import {useDispatch, useSelector} from "react-redux";
import { themeSettings } from "theme";
import Layout from "scenes/layout";
import Dashboard from "scenes/dashboard";
import Products from "scenes/products";
import Customers from "scenes/customers";
import Transactions from "scenes/transactions";
import Geography from "scenes/geography";
import Overview from "scenes/overview";
import Daily from "scenes/daily";
import Monthly from "scenes/monthly";
import Breakdown from "scenes/breakdown";
import ProductDetails from "scenes/ProductDetails";
import Performance from "scenes/performance";
import Login from "scenes/loginPage";
import {logout, refreshAccessToken, verifyToken} from "./features/auth/authSlice.js"; // Import the logout action


function App() {
    const mode = useSelector((state) => state.global.mode);
    const user = useSelector((state) => state.auth.user);
    const isAuthenticated = !!user;

    const dispatch = useDispatch(); // Initialize dispatch
    useEffect(() => {
        if (isAuthenticated) {
            const refreshTokenInterval = setInterval(() => {
                dispatch(refreshAccessToken());
            }, 30 * 60 * 1000); // Refresh token every 30 minutes

            return () => clearInterval(refreshTokenInterval);
        }
    }, [isAuthenticated, dispatch]);

    useEffect(() => {
        if (isAuthenticated) {
            dispatch(verifyToken()).then((result) => {
                if (result.payload && result.payload.code) {
                    // Token is invalid, logout the user
                    dispatch(logout());
                }
            });
        }
    }, [isAuthenticated, dispatch]);

    const theme = useMemo(() => createTheme(themeSettings(mode)), [mode]);

    return (
        <div className="app">
            <BrowserRouter basename="/agent">
                <ThemeProvider theme={theme}>
                    <CssBaseline />

                    <Routes>
                        {isAuthenticated && (
                            <Route
                                path="/"
                                element={<Layout />}
                            >
                                <Route path="/" element={<Dashboard />} />
                                <Route path="/All Properies/product/:slug" element={<ProductDetails />} />
                                <Route path="/All Properies" element={<Products />} />
                                <Route path="/customers" element={<Customers />} />
                                <Route path="/Request for sale" element={<Transactions />} />
                                <Route path="/Enquiries" element={<Geography />} />
                                <Route path="/overview" element={<Overview />} />
                                <Route path="/daily" element={<Daily />} />
                                <Route path="/monthly" element={<Monthly />} />
                                <Route path="/breakdown" element={<Breakdown />} />
                                <Route path="/performance" element={<Performance />} />
                                <Route path="/logout" element={<Logout />} />

                            </Route>
                        )}
                        <Route
                            path="/"
                            element={isAuthenticated ? <Navigate to="/" replace /> : <Login />}
                        />
                    </Routes>
                </ThemeProvider>
            </BrowserRouter>
        </div>
    );




    // Logout component
    function Logout() {
        dispatch(logout()); // Dispatch the logout action
        return <Navigate to="/" replace />;
    }
}

export default App;
