import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./features/auth/authSlice";
import propertyReducer from "./features/properties/propertySlice";
import globalReducer from "./features/global/index";
import { api } from "state/api";
import propertyDetailsReducer from "./features/properties/propertyDetailsSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    properties: propertyReducer,
    global: globalReducer,
    [api.reducerPath]: api.reducer,
    property: propertyDetailsReducer,

  },
  middleware: (getDefault) => getDefault().concat(api.middleware),
});
