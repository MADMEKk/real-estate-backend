const { alias, configPaths } = require('react-app-rewire-alias');
const { override } = require('customize-cra');

module.exports = override(
  alias({
      components: './src/components',
      scenes: './src/scenes',
      state: './src/state',
      theme: './src/theme',
      assets: './src/assets',


      })
);